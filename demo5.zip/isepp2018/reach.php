<!DOCTYPE HTML>
<head lang="en">
    <meta charset="UTF-8">
    <meta name="viewport" content="initial-scale=1,width=device-width">
    <title>ISEPP 2018 - How to reach us?</title>
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,700" rel="stylesheet">
    <link rel="stylesheet" href="resources/css/bootstrap.min.css">
    <link rel="stylesheet" href="resources/css/main.min.2.css">
    <script type="text/javascript" src="resources/js/jquery.min.js"></script>
    <script type="text/javascript" src="resources/js/main.min.js"></script>
</head>
<body>
<header class="header container-fluid">
    <div class="row">
        <div class="col-sm-12 col-md-3 brand-container">
            <i class="nav-small-show-button glyphicon glyphicon-menu-hamburger"></i>
            <a class="brand" href=".">
                ISEPP
                <span>2018</span>
            </a>
        </div>
        <nav class="col-sm-12 col-md-9 text-right nav-large-container">
            <a class="nav-link" href="." title="Home">Home</a><a class="nav-link" href="schedule.php" title="Schedule">Schedule</a><a class="nav-link" href="speakers.php" title="Speakers">Speakers</a><a class="nav-link" href="sponsors.php" title="Sponsors">Sponsors</a><a class="nav-link" href="posters.php" title="Call For Posters">Call For Posters</a><a class="nav-link" href="registration.php" title="Registration">Registration</a><a class="nav-link active" href="reach.php" title="How to reach us?">How to reach us?</a><a class="nav-link" href="contact.php" title="Contact">Contact</a>        </nav>
    </div>
</header>
<nav class="nav-small-container">
    <h2>
        Menu
        <i class="nav-small-hide-button glyphicon glyphicon-remove"></i>
    </h2>
    <a class="nav-link" href="." title="Home">Home</a><a class="nav-link" href="schedule.php" title="Schedule">Schedule</a><a class="nav-link" href="speakers.php" title="Speakers">Speakers</a><a class="nav-link" href="sponsors.php" title="Sponsors">Sponsors</a><a class="nav-link" href="posters.php" title="Call For Posters">Call For Posters</a><a class="nav-link" href="registration.php" title="Registration">Registration</a><a class="nav-link active" href="reach.php" title="How to reach us?">How to reach us?</a><a class="nav-link" href="contact.php" title="Contact">Contact</a></nav>    <div class="container content">
        <div class="row">
            <div class="col-sm-12 text-center">
                <img style="max-width: 800px;margin: auto;" src="resources/drawable/how_to_reach.jpg" width="100%">
            </div>
        </div>
    </div>
<div class="container-fluid">
    <div class="row footer">
        <div class="col-sm-12">
            &copy; 2017 NIT Kurukshetra
        </div>
    </div>
</div>
</body>
</html>