<!doctype html>
<html lang="en">
  <head>
    <?php require("include.php");?>
  </head>

  <body>

    <div class="container">
       <?php require('header.php'); showHeader(2); ?>
      <div class="row mb-2">
          <div class="col-md-6">
            <div class="row">
              <div class="card flex-md-row mb-4 box-shadow h-md-350">
                <div class="card-body d-flex flex-column align-items-start">
                  <strong class="d-inline-block mb-2 text-primary">Chief Guest</strong>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/44.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. V. K. Saraswat </b></h6>
                      <p>Hon'ble Member NITI Aayog and Former Chief, DRDO <br>Govt. of India</p>
                    </div>
                  </div>
                   <!-- <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./images/university-of-maryland.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Name of Person</b></h6>
                      <p>afsf  description</p>
                      <p>fas</p>
                    </div>
                  </div> -->
                </div>
              </div>
            </div>
            
            <div class="row">
            <div class="card flex-md-row mb-4 box-shadow h-md-400">
              <div class="card-body d-flex flex-column align-items-start">
                <strong class="d-inline-block mb-2 text-success">Guest of Honour</strong>
                <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/48.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>V K Raizada</b></h6>
                      <p>Executive Director<br>IndianOil</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/49.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. S.K. Salwan</b></h6>
                      <p>DRDO<br>India</p>
                    </div>
                  </div>
                  <!-- <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./images/university-of-maryland.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Name of Person</b></h6>
                      <p>afsf  description</p>
                      <p>fas</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./images/university-of-maryland.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Name of Person</b></h6>
                      <p>afsf  description</p>
                      <p>fas</p>
                    </div>
                  </div> -->
              </div>
            </div>
          </div>

          <div class="row">
              <div class="card flex-md-row mb-4 box-shadow h-md-350">
                  <div class="card-body d-flex flex-column align-items-start">
                   <strong class="d-inline-block mb-2 text-success">Distinguished Speakers </strong>
                <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/3.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Suresh Aggarwal</b></h6>
                      <p>University of Illinois at Chicago,</br>Chicago, USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/22.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Ryo S. Amano</b></h6>
                      <p>University of Wisconsin Milwaukee,</br>USA</p>
                      
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/8.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Rachid Bennacer</b></h6>
                      <p>Ecole Normale Paris-Saclay,</br>France</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/14.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Renato Machado Cotta</b></h6>
                      <p>National Commission of Nuclear Energy,</br>Brazil</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/4.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Ashoke De</b></h6>
                      <p>Indian Institute of Technology Kanpur,</br>Kanpur, India</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/19.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Marcel de Lemos</b></h6>
                      <p>Instituto Tecnologico de Aeronautica,</br>Brazil</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/20.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Mohammed El Ganaoui</b></h6>
                      <p>University of Lorraine,</br>France</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/2.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Ashwani K. Gupta</b></h6>
                      <p>University of Maryland,</br>College Park, USA</p>
                    </div>
                  </div>

                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/15.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Kemal Hanjalic</b></h6>
                      <p>Delft University of Technology,</br>The Netherlands</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/25.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Kazhikathra Kailasanath</b></h6>
                      <p>Naval Research Laboratory,</br>USA</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/12.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Somrat Kerdsuwan</b></h6>
                      <p>King Mongkut’s University of Technology,</br>North Bangkok</p>
                      <p>fas</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/27.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Jens Klingmann</b></h6>
                      <p>Lund University</br>Sweden</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/17.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Naveen Kumar</b></h6>
                      <p>DTU,</br>New Delhi</p>
                    </div>
                  </div>
                  </div>
                </div>
            </div>
        </div>

        <!-- second half  -->
        <div class="col-md-6">
           <div class="row">
            <div class="card flex-md-row mb-4 box-shadow h-md-400">
              <div class="card-body d-flex flex-column align-items-start">
                <strong class="d-inline-block mb-2 text-success">Distinguished Speakers </strong>
                
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/5.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Abhijit Kushari</b></h6>
                      <p>Indian Institute of Technology Kanpur,</br>Kanpur, India</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/21.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Peter Lindstedt</b></h6>
                      <p>Imperial College,</br>London</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/24.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Hameed Metghalchi</b></h6>
                      <p>Northeastern University,</br>USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/11.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Hukam C. Mongia</b></h6>
                      <p>Purdue University,</br>USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/13.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Biagio Morrone</b></h6>
                      <p>Universita' Degli Studi Della Campania,</br>Italy</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/26.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Gabriel D. Roy</b></h6>
                      <p>CPNE Consultants,</br>USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/1.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Akshai Runchal</b></h6>
                      <p>Analytic & Computational Research Inc.</br>Los Angeles, USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/6.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Kunio Yoshikawa</b></h6>
                      <p>Tokyo Institute of Technology,</br>Japan</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/28.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Kenneth Yu</b></h6>
                      <p>University of Maryland,</br>USA</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/38.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Yunho Hwang</b></h6>
                      <p>University of Maryland,</br>USA</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/39.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Ray Lin</b></h6>
                      <p>TaiCrystal Int. Technology Co. Ltd.,</br>Taiwan</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/40.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Keiichi Okai</b></h6>
                      <p>Japan Aerospace Exploration Agency,</br>Japan</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/41.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Amitava Dattan</b></h6>
                      <p>Jadavpur University Kolkata,</br>India</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/42.jpg" class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Saptarshi Basu</b></h6>
                      <p>Indian Institute of Science Bengaluru,</br>India</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/23.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Sutapat Kwankaomeng</b></h6>
                      <p>King Mongkut’s University of Technology Ladkrabang,</br>Thailand</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/45.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Achintya Mukhopadhyay</b></h6>
                      <p>Jadavpur University Kolkata,</br>India</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');">
                    <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/46.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Debasis Chakraborty</b></h6>
                      <p>DRDL,</br>India</p>
                    </div>
                  </div>
                   <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/47.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Mohammed Ibrahim Sugarno</b></h6>
                      <p>Indian Institute of Technology Kanpur,</br>India</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/51.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Dr. Manish K Tiwari</b></h6>
                      <p>University College London,</br>London</p>
                    </div>
                  </div>
                  <div class="row speaker" onclick= "speaker('name.html');" >
                     <div class="col-4">
                      <img src="./isepp2018/resources/drawable/speakers/50.jpg"  class="img-thumbnail" height="200" width="200">
                    </div>
                    <div class="col">
                      <h6><b>Prof. Satya Chakravarthy</b></h6>
                      <p>Indian Institute of Technology Madras,</br>India</p>
                    </div>
                  </div>
              </div>
            </div>
          </div>
          
            <!-- <div class="row">
                <div class="card flex-md-row mb-4 box-shadow h-md-350">
                  <div class="card-body d-flex flex-column align-items-start">
                    <strong class="d-inline-block mb-2 text-primary">Who should attend?</strong>
                     <small>  Researchers and engineers from academia, R&D organizations and industries working in the areas of fuels, energy, combustion, power, propulsion, hypersonics, air pollution, sensors and diagnostics, modeling, fossil- and bio-fuels, alternative energy, energy-water nexus, droplets and atomization, novel combustion concepts, engine combustion, gas turbine combustion, swirl flows and other related areas. </small>
                  </div>
                </div>
            </div> -->
        </div>
        <!--  -->
      </div>
    </div>
    <footer class="blog-footer">
      <p>&copy; 2018 - 19  <a href="https://nitkkr.ac.in">NIT KURUKSHETRA</a>.</p>
    </footer>
    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>
  
    <script src="js/popper.min.js"></script>
    <script src="js/bootstrap.min.js"></script>
    <script src="js/holder.min.js"></script>
    <script src="js/main.js"></script>
   
  </body>
</html>
