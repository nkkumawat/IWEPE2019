<?php

echo '<footer class="blog-footer">
		<div class="row">
			<div class="col-md-1"></div>
			<div class="col-md-3 col-sm-12" style="text-align:left;">
			<h6 class=" theme-color"> NIT Kurukshetra</h6>
			<p class="float-left">

			National Institute of Technology Kurukshetra enjoys the reputation of being a centre of excellence, facilitating quality technical and management education, research and training. It has been conferred the status of being an Institution of National Importance.
				<a class="theme-color" href="http://nitkkr.ac.in" target="_blank">Rad more...</a>

			</p><br><br><br><br>
			</div>
			<div class="col-md-5 col-sm-12">
				<p>&copy; 2018 - 19  <a class="footer-text" href="https://nitkkr.ac.in"> NIT KURUKSHETRA</a>
      			&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp; <a class="footer-text"  href="downloads.php" > DOWNLOADS</a>
      		</p><br><br>
			</div>
			<div class="col-md-3 col-sm-12" style="text-align:left;">
			<h6 class=" theme-color"> Contact Us</h6>
			<p class="float-left">
			    Training and Placement Cell<br>
			    National Institute of Technology Kurukshetra<br>
			    Kurukshetra 136119, India<br>
			    Telephone: +91 1744 238491, +91 1744 233302
			</p><br><br>
			</div>
		</div>
	  </footer>'

?>