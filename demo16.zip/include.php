<?php

	echo '
	<meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="National Institute of Technology (NIT) Kurukshetra   organizing an International Workshop on  Energy, Power and ENVIRONMENT  ">
    <meta name="description" content=" Power and Propulsion that started in 2004 with a review of the Status of Combustion in India and has evolved into a forum for the status of Sustainable Energy Development for Power and Propulsion worldwide.
        For this year, the general theme is Clean Energy Production & Utilization. We expect to have ontributions from world-renowned experts on topics that include Power, Propulsion, Pulse Detonation, Environmental Sustainability, Combustion, Emissions, Advanced Diagnostics etc ">
    <meta name="author" content="Narendra Kumawawt">
    <meta name="keywords" content="IWEPE, IWEPE 2019, ISEPP 2019, ISEPP 2018, NIT KKR, NIT kurukshetra, NATIONAL INSTITUTE OF TECHNOLOGY, INTERNATIONAL WORKSHOP ON ENERGY POWER and ENVIRONMENT, Narendra Kumawawt, ">
    <title>IWEPE 2019 | NIT KURUKSHETRA</title>
    <!-- Bootstrap core CSS -->
    <link href="css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="https://fonts.googleapis.com/css?family=Roboto" rel="stylesheet">
    <link href="css/blog.css" rel="stylesheet">
    <link href="css/main.css" rel="stylesheet">
     
	';


?>