<?php

echo '<footer class="blog-footer">
      		<p>&copy; 2018 - 19  <a class="footer-text" href="https://nitkkr.ac.in"> NIT KURUKSHETRA</a>
      			&nbsp;&nbsp;&nbsp;|&nbsp;&nbsp; <a class="footer-text"  href="downloads.php" > DOWNLOADS</a>

      		</p>
	  </footer>'

?>